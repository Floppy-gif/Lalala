from django import forms

from .models import Bastian


class SelestiForm(forms.ModelForm):
  class Meta:
    model = Bastian
    fields = ('__all__')