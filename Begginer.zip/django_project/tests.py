from django.test import TestCase

from .models import Bastian, Selesti


class SelestiTestCase(TestCase):
    def setUp(self):
      self.group = Selesti.objects.create(group='SELESTI-1', entry_year=2020, department='GUMPI')
      self.person = Bastian.objects.create(name='StudentI', age=18, info=self.group)
      
    def test_group_name(self):
      selesi2 = Bastian.objects.get(name='StudentI', age=18)