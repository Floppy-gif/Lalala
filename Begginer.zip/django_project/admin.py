from django.contrib import admin

from .models import Bastian, Selesti

admin.site.register(Bastian)
admin.site.register(Selesti)