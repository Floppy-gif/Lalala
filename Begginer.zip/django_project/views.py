from django.shortcuts import redirect, render
from django.views.decorators.csrf import csrf_exempt

from .forms import SelestiForm
from .models import Selesti


@csrf_exempt
def create_student(request, *args, **kwargs):
  f = SelestiForm(request.POST or None)
  if request.method == 'POST' and f.is_valid():
    stud_name = f.cleaned_data['name']
    stud_age = f.cleaned_data['age']
    stud_info = f.cleaned_data['info']
    f.save()
    return redirect('create_student')
  else:
    f = SelestiForm()
  return render(request, 'index.html', {'form': f})

def person_list(request):
  person = Selesti.objects.all()
  return render(request, "person_list.html", {'person': person})