from django.db import models


class Selesti(models.Model):
  group = models.CharField(max_length=10)
  entry_year= models.IntegerField()
  department = models.CharField(max_length=100)
  
  def __str__(self):
    return self.group


class Bastian(models.Model):
  name = models.CharField(max_length=100)
  age = models.IntegerField()
  info = models.ForeignKey(Selesti(), on_delete=models.CASCADE)
  def __str__(self):
    return self.name
